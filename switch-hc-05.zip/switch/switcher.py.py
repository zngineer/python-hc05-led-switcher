import time
from Tkinter import *
from PIL import Image, ImageTk
import bluetooth
import sys

root = Tk()
frame = Frame(root)
frame.pack()

port = 1
sock=bluetooth.BluetoothSocket( bluetooth.RFCOMM )

def lightOn():
    sock.send("1")

def lightOff():
    sock.send("0")

def reConnect():
	bd_addr = adrs.get()
	sock.connect((bd_addr, port))
	connectlabel.config(text = "connected to bluetooth module", fg='green')
	
def scanDevices():
	target_name = "HC-05"
	target_address = None

	nearby_devices = bluetooth.discover_devices()
	for bdaddr in nearby_devices:
		if target_name == bluetooth.lookup_name( bdaddr ):
			target_address = bdaddr
			break

	if target_address is not None:
		print "found target bluetooth device with address ", target_address
		adrs.delete(0, END)
		adrs.insert(0, bdaddr)
	else:
		print "no device found"
		adrs.delete(0, END)
		adrs.insert(0, "could not find device, rescan")


pic = Image.open("images\led.jpg")
pic2 = Image.open("images\ledswitcherlogo.png")
logo = ImageTk.PhotoImage(pic)
logo2 = ImageTk.PhotoImage(pic2)
adrs = Entry(frame, text="bluetooth address", width="50")
adrs.pack()
thisisaddress = Label(frame, text="enter bluetooth address here",fg="red")
thisisaddress.pack()




ledimage = Label(frame, image=logo2)
ledimage.pack()

ledswitcherlogo = Label(frame, image=logo)
ledswitcherlogo.pack()

partialcredits = Label(frame, text="power on and pair with HC-05 with the computer before use",fg='red')
partialcredits.pack()



connectlabel = Label(frame, text="not connected",fg='red')
connectlabel.pack()






partialcredits = Label(frame, text="terrible art and programming by Zachary Murtishi, most credit to the guys who made pybluez",fg="red")
partialcredits.pack()


hmu = Label(frame, text="hmu @ zachary.murtishi@uconn.edu",fg='red')
hmu.pack()


bluebutton = Button(frame, text="Lights On!", fg="red")
bluebutton.config(command=lightOn)
bluebutton.pack( side = LEFT )
greenbutton = Button(frame, text="Connect to HC-05!", fg="red")
greenbutton.config(command=reConnect)
greenbutton.pack( side = RIGHT )
yellowbutton = Button(frame, text="Scan Bluetooth devices", fg="red")
yellowbutton.config(command=scanDevices)
yellowbutton.pack( side = RIGHT )
redbutton = Button(frame, text="Lights Off!", fg="red")
redbutton.config(command=lightOff)
redbutton.pack( side = RIGHT )



bluebutton.config( height = 50, width = 50)
redbutton.config( height = 50, width = 50)
greenbutton.config( height = 10)
yellowbutton.config( height = 10)

root.mainloop()
